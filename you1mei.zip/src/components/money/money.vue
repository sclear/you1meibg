<template>
  <div class="money">
    <el-tabs v-model="activeName">
      <el-tab-pane label="案例" name="first"></el-tab-pane>
    </el-tabs>
    <div>
      <el-select size="mini" v-model="value4" clearable placeholder="选择端口">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        ></el-option>
      </el-select>
      <el-button size="mini" @click="CLOSE(0)" type="primary">+添加端口</el-button>
      <el-button size="mini" @click="CLOSE(1)" type="primary">+添加分类</el-button>
      <el-button size="mini" @click="CLOSE(2)" type="primary">+模块</el-button>
      <!-- <el-button size="mini" @click="CLOSE(3)" type="primary">+功能点</el-button> -->
    </div>
    <model @CLOSE="CLOSE" v-if="model" Ttxt="添加">
      <div slot="modelBody">
        <!-- 添加端口 -->
        <div v-if="nums === 0">
          <span class="spanName">端口名称:</span>
          <el-input class="w240" size="small" v-model="Dkname" placeholder="请输入端口名称"></el-input>
        </div>
        <!-- 添加分类 -->
        <div v-if="nums === 1">
          <div>
            <span class="spanName">选择端口:</span>
            <el-select class="w240" size="small" v-model="dk" clearable placeholder="选择端口">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <div class="mt10">
            <span class="spanName">分类名称:</span>
            <el-input class="w240" size="small" v-model="Dkname" placeholder="请输入内容"></el-input>
          </div>
        </div>
        <!-- 添加模块 -->
        <div v-if="nums === 2">
          <div>
            <span class="spanName">选择端口:</span>
            <el-select class="w240" size="small" v-model="dk" clearable placeholder="选择端口">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <div class="mt10">
            <span class="spanName">选择分类:</span>
            <el-select class="w240" size="small" v-model="fl" clearable placeholder="选择模块">
              <el-option
                v-for="item in optionfl"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <div class="mt10">
            <span class="spanName">模块名称:</span>
            <el-input class="w240" size="small" v-model="Dkname" placeholder="请输入内容"></el-input>
          </div>
        </div>
        <!-- 添加功能 -->
        <div v-if="nums === 3">
          <!-- <div>
            <span class="spanName">选择端口:</span>
            <el-select class="w240" size="small" v-model="dk" clearable placeholder="选择端口">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <div class="mt10">
            <span class="spanName">选择分类:</span>
            <el-select class="w240" size="small" v-model="fl" clearable placeholder="选择分类">
              <el-option
                v-for="item in optionfl"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div> -->
          <div class="mt10">
            <span class="spanName">选择模块:</span>
            <el-select class="w240" size="small" v-model="mk" clearable placeholder="选择模块">
              <el-option
                v-for="item in optionmk"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <div class="mt10">
            <span class="spanName">功能名称:</span>
            <el-input class="w240" size="small" v-model="Dkname" placeholder="请输入内容"></el-input>
          </div>
          <div class="mt10">
            <span class="spanName">价格范围:</span>
            <el-input class="w240" size="small" v-model="Dkname" placeholder="请输入价格范围"></el-input>
          </div>
          <div class="mt10">
            <span class="spanName">价格:</span>
            <el-input class="w240" size="small" v-model="Dkname" placeholder="请输入价格"></el-input>
          </div>
          <div class="mt10">
            <span class="spanName spanLH">功能简介:</span>
            <textarea class="w240 textarea" placeholder="简介"></textarea>
          </div>
        </div>
        <el-button class="Up" size="small" type="primary">提交</el-button>
      </div>
    </model>
  </div>
</template>

<script>
import model from "./../common/model";
export default {
  data() {
    return {
      activeName: "first",
      //端口
      options: [
        {
          value: "APP",
          label: "APP"
        },
        {
          value: "IOS",
          label: "IOS"
        }
      ],
      value4: "APP",
      dk:'',
      //分类
      optionfl: [
        {
          value: "m",
          label: "m"
        },
        {
          value: "m2",
          label: "m2"
        }
      ],
      fl: "",
      //模块
      optionmk: [
        {
          value: "mm1",
          label: "mm1"
        },
        {
          value: "mm2",
          label: "mm2"
        }
      ],
      mk: "",

      model: false,
      Dkname: "",
      ss:false,
      nums:'',      //
    };
  },
  methods: {
    CLOSE(res) {
      this.nums = res;
      this.model = !this.model;
    }
  },
  components: {
    model
  }
};
</script>

<style lang='less' scoped >
.money {
}

//modle
.w240 {
  width: 240px;
}
.Up {
  margin: 20px auto auto 150px;
}
.spanName {
  display: inline-block;
  text-align: right;
  padding-right: 10px;
  width: 100px;
}
.spanLH{
    height:42px;
}
.textarea{
    display: inline-block;
    height:42px;
}
.mt10{
    margin-top: 10px;
}
</style>
