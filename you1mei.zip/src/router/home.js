export default [
    {
        path: '/',
        component: resolve => require(['@/components/client/client'], resolve)
    },
    {
        path: '/cases',
        component: resolve => require(['@/components/case/cases'], resolve)
    },
    {
        path: '/client',
        component: resolve => require(['@/components/client/client'], resolve)
    },
    {
        path: '/money',
        component: resolve => require(['@/components/money/money'], resolve)
    }
]